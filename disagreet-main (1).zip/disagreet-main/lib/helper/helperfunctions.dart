import 'dart:math';

import 'package:disagreet_flutter/helper/constants.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HelperFunctions {
  static const String _sharedPreferenceUserLoggedInKey = "ISLOGGEDIN";
  static const String _sharedPreferenceFirstNameKey = "FIRSTNAMEKEY";
  static const String _sharedPreferenceLastNameKey = "LASTNAMEKEY";
  static const String _sharedPreferenceUserEmailKey = "USEREMAILKEY";
  static const String _sharedPreferenceUidKey = "UIDKEY";
  static const String _sharedPreferenceImageUrlKey = "IMAGEURLKEY";

  static List<Color> _colors = [
    Colors.deepOrange,
    Colors.teal,
    Colors.yellow.shade600,
    Colors.red,
  ];

  static Color getRandomColor(int seed) {
    var random = Random(seed);
    return _colors[random.nextInt(_colors.length)];
  }

  // saving data to sharedPreference

  static Future<bool> saveUserLoggedInSharedPreference(
      bool isUserLoggedIn) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setBool(
        _sharedPreferenceUserLoggedInKey, isUserLoggedIn);
  }

  static Future<bool> saveUidSharedPreference(String uid) async {
    print(uid);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setString(_sharedPreferenceUidKey, uid);
  }

  static Future<bool> saveUserFirstNameSharedPreference(
      String firstName) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setString(_sharedPreferenceFirstNameKey, firstName);
  }

  static Future<bool> saveUserLastNameSharedPreference(String lastName) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setString(_sharedPreferenceLastNameKey, lastName);
  }

  static Future<bool> saveUserEmailSharedPreference(String userEmail) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setString(_sharedPreferenceUserEmailKey, userEmail);
  }

  static Future<bool> saveImageUrlSharedPreference(String imageUrl) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await prefs.setString(_sharedPreferenceImageUrlKey, imageUrl);
  }
  // get data from SharedPreferences

  static Future<bool?> getUserLoggedInSharedPreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_sharedPreferenceUserLoggedInKey);
  }

  static Future<String?> getUidSharedPreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sharedPreferenceUidKey);
  }

  static Future<String?> getUserFirstNameSharedPreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sharedPreferenceFirstNameKey);
  }

  static Future<String?> getUserLastNameSharedPreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sharedPreferenceLastNameKey);
  }

  static Future<String?> getUserEmailSharedPreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sharedPreferenceUserEmailKey);
  }

  static Future<String?> getImageUrlSharedPreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sharedPreferenceImageUrlKey);
  }

  static Future saveUserInfo(
      {required String firstName,
      required String lastName,
      required String email,
      required bool login,
      required String uid,
      String imageUrl = ""}) async {
    await saveUserEmailSharedPreference(email);
    await saveUserFirstNameSharedPreference(firstName);
    await saveUserLastNameSharedPreference(lastName);
    await saveUserLoggedInSharedPreference(login);
    await saveUidSharedPreference(uid);
    await saveImageUrlSharedPreference(imageUrl);
    await setUserConstants();
    return true;
  }

  static Future setUserConstants() async {
    Constants.myEmail = await getUserEmailSharedPreference() as String;
    Constants.myFirstName = await getUserFirstNameSharedPreference() as String;
    Constants.myLastName = await getUserLastNameSharedPreference() as String;
    Constants.myUid = await getUidSharedPreference() as String;
    Constants.myImageUrl = await getImageUrlSharedPreference() as String;
  }

  static getConversationId(String a, String b, String topic) {
    if (a.compareTo(b) == 1) {
      return "${b}_${a}_$topic";
    } else {
      return "${a}_${b}_$topic";
    }
  }

  // Video 3 @ 9:00

}
