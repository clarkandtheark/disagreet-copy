class Constants {
  static String myFirstName = "";
  static String myLastName = "";
  static String myUid = "";
  static String myEmail = "";
  static String myImageUrl = "";
}
