import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/database/base_database_repository.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/helper/helperfunctions.dart';
import 'package:disagreet_flutter/models/user_model.dart';
import 'package:disagreet_flutter/storage/storage_repository.dart';

class DatabaseRepository extends BaseDatabaseRepository {
  final FirebaseFirestore _firebaseFirestore = FirebaseFirestore.instance;

  @override
  Stream<User> getUser() {
    return _firebaseFirestore
        .collection('users')
        .doc(Constants.myUid)
        .snapshots()
        .map((snap) => User.fromSnapshot(snap));
  }

  @override
  Future<void> updateUserPicture(String imageName) async {
    String downloadUrl = await StorageRepository().getDownloadUrl(imageName);
    await HelperFunctions.saveImageUrlSharedPreference(downloadUrl);
    Constants.myImageUrl = downloadUrl;

    return _firebaseFirestore
        .collection('users')
        .doc(Constants.myUid)
        .update({'imageUrl': downloadUrl});
  }

  @override
  updateRating(int rating, String otherID, String ratingType) async {
    return _firebaseFirestore
        .collection('users')
        .doc(otherID)
        .collection('rating')
        .add({'rating': rating, 'user': otherID, 'type': ratingType});
  }
}
