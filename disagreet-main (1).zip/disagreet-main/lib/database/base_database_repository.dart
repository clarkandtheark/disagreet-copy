import 'package:disagreet_flutter/models/user_model.dart';

abstract class BaseDatabaseRepository {
  Stream<User> getUser();
  Future<void> updateUserPicture(String imageName);
  updateRating(int rating, String otherID, String ratingType);
}
