import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/helperfunctions.dart';
import 'package:disagreet_flutter/modal/UserClass.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/views/mainPage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthMethods {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseMethods databaseMethods = DatabaseMethods();
  UserClass? _userFromFirebaseUser(User user) {
    return user != null ? UserClass(userId: user.uid) : null;
  }

  Future? signInWithEmail(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      User firebaseUser = result.user as User;
      return _userFromFirebaseUser(firebaseUser);
    } catch (e) {
      print(e);
    }
  }

  Future? signUpWithEmail(String email, String password) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      User firebaseUser = result.user as User;
      return _userFromFirebaseUser(firebaseUser);
    } catch (e) {
      print(e);
    }
  }

  Future? resetPassword(String email) async {
    try {
      return await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      print(e);
    }
  }

  Future signInWithGoogle(BuildContext context) async {
    final GoogleSignIn _googleSignIn = GoogleSignIn();
    final GoogleSignInAccount? googleSignInAccount =
        await _googleSignIn.signIn();
    final GoogleSignInAuthentication googleSignInAuthentication =
        await googleSignInAccount!.authentication;
    final AuthCredential credential = GoogleAuthProvider.credential(
        idToken: googleSignInAuthentication.idToken,
        accessToken: googleSignInAuthentication.accessToken);

    UserCredential result = await _auth.signInWithCredential(credential);
    if (result == null) {
      return;
    } else {
      QuerySnapshot userSearch;
      databaseMethods
          .getUserByUserEmail(result.user!.email as String)
          .then((val) {
        userSearch = val;
        print(userSearch.docs[0].id);

        //Create New User if Google User doesn't exist
        if (userSearch.size == 0) {
          databaseMethods.uploadUserInfo({
            'firstName': result.user!.displayName!.split(" ")[0],
            'lastName': result.user!.displayName!.split(" ")[1],
            'email': result.user!.email,
            'imageUrl': result.user!.photoURL
          });
        } else {
          //TODO: Figure out how profile images will work here and verify that it will go to the main page correctly.
          HelperFunctions.saveUserInfo(
                  firstName: userSearch.docs[0]['firstName'],
                  lastName: userSearch.docs[0]['lastName'],
                  email: userSearch.docs[0]['email'],
                  uid: userSearch.docs[0].id,
                  imageUrl: userSearch.docs[0]['imageUrl'],
                  login: true)
              .then((val) {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => const MainPage(
                          startingIndex: 0,
                        )));
          });
        }
      });
    }
  }

  Future? signOut() async {
    try {
      HelperFunctions.saveUserInfo(
          firstName: "",
          lastName: "",
          email: "",
          login: false,
          uid: "",
          imageUrl: "");

      return _auth.signOut();
    } catch (e) {
      print(e);
    }
  }
}
