import 'dart:core';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/src/iterable_extensions.dart';
import 'package:disagreet_flutter/helper/constants.dart';

class DatabaseMethods {
  getUserByUsername(String firstName) async {
    return await FirebaseFirestore.instance
        .collection("users")
        .where("firstName", isEqualTo: firstName)
        .get();
  }

  getUserByUserEmail(String userEmail) async {
    return await FirebaseFirestore.instance
        .collection("users")
        .where("email", isEqualTo: userEmail)
        .get();
  }

  uploadUserInfo(userMap) {
    return FirebaseFirestore.instance
        .collection("users")
        .add(userMap)
        .catchError((e) {
      print(e.toString());
    });
  }

  updateRating(int rating, String otherID, String ratingType) async {
    print(rating);
    FirebaseFirestore.instance
        .collection('users')
        .doc(otherID)
        .collection('rating')
        .add({'rating': rating, 'user': otherID, 'type': ratingType});
  }

  createConversation(String conversationId, conversationMap) {
    FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationId)
        .set(conversationMap)
        .catchError((e) {
      print(e.toString());
    });
  }

  addUserToTopic(String topicName, String userId, String fullName, stanceNum,
      stanceEntry, imageUrl) {
    var stance = {
      "stanceNum": stanceNum,
      "stanceEntry": stanceEntry,
      "fullName": fullName,
      "imageUrl": imageUrl,
    };
    FirebaseFirestore.instance
        .collection("topic")
        .doc(topicName)
        .collection("topic-users")
        .doc(topicName + '-' + userId)
        .set(stance)
        .catchError((e) => print(e.toString()));
  }

  addConversationMessage(String conversationId, messageMap) {
    FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationId)
        .collection("messages")
        .add(messageMap)
        .catchError((e) => print(e.toString()));
  }

  updateLatestMessage(String conversationId, Map messageMap) {
    FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationId)
        .update({"latestMessage": messageMap}).catchError(
            (e) => print(e.toString()));
  }

  getConversationById(String conversationID) {
    return FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationID)
        .get();
  }

  getConversationMessage(String conversationID) async {
    print("Messages retrieved");
    return await FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationID)
        .collection("messages")
        .orderBy("time", descending: false)
        .snapshots();
  }

  getConversations(String uid) async {
    return FirebaseFirestore.instance
        .collection("conversation")
        .where("uids", arrayContains: uid)
        .snapshots();
  }

  getConversationsByTopic(String topic) {
    return FirebaseFirestore.instance
        .collection("conversation")
        .where("topic", isEqualTo: topic)
        .get();
  }

  getAverageRatingByTopic(String topic) async {
    print("Calculating...");
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection("users")
        .doc(Constants.myUid)
        .collection("rating")
        .where("type", isEqualTo: topic)
        .get();

    if (querySnapshot.size != 0) {
      var avg =
          querySnapshot.docs.map((m) => m['rating']).reduce((a, b) => a + b) /
              querySnapshot.size;
      return avg;
    } else {
      return null;
    }
  }

  getConversationsByName(String name) {
    return FirebaseFirestore.instance
        .collection("conversation")
        .where("names", arrayContains: name)
        .get();
  }

  changeConversationStatus(String conversationId, String status) {
    return FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationId)
        .update({"status": status});
  }

  requestConversationEnd(
      String conversationId, String status, String requester) {
    return FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationId)
        .update({"status": status, "requester": requester});
  }

  getRequesterName(String conversationId) async {
    return FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationId)
        .get()
        .then((DocumentSnapshot ds) {
      return ds["requester"];
    });
  }

  getConversationStatus(String conversationId) async {
    return FirebaseFirestore.instance
        .collection("conversation")
        .doc(conversationId)
        .get()
        .then((DocumentSnapshot ds) {
      return ds["status"];
    });
  }

  Future getAllTopics() async {
    return await FirebaseFirestore.instance.collection("topic").get();
  }

  Future getTopicByName(String name) async {
    print("This is Name " + name);
    return await FirebaseFirestore.instance
        .collection("topic")
        .where("name", isEqualTo: name)
        .get();
  }

  Future getTopicUserById(String topicId, String userId) {
    print("UID");
    print(userId);
    return FirebaseFirestore.instance
        .collection("topic")
        .doc(topicId)
        .collection("topic-users")
        .doc(topicId + "-" + userId)
        .get();
  }

  Future<QuerySnapshot<Map<String, dynamic>>> getTopicUserForMatching(
      String topicId, bool isPositive) {
    if (isPositive) {
      return FirebaseFirestore.instance
          .collection("topic")
          .doc(topicId)
          .collection("topic-users")
          .where("stanceNum", isLessThanOrEqualTo: 0)
          .get();
    } else {
      return FirebaseFirestore.instance
          .collection("topic")
          .doc(topicId)
          .collection("topic-users")
          .where("stanceNum", isGreaterThanOrEqualTo: 0)
          .get();
    }
  }

  calculatePeopleTalking(String topicId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection("topic")
        .doc(topicId)
        .collection("topic-users")
        .get();
    var numPeopleTalking = snapshot.size;
    FirebaseFirestore.instance
        .collection("topic")
        .doc(topicId)
        .update({"peopleTalking": numPeopleTalking});
  }
}
