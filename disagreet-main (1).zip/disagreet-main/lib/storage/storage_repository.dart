import 'dart:io';

import 'package:disagreet_flutter/database/database_repository.dart';
import 'package:disagreet_flutter/storage/base_storage_repository.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

class StorageRepository extends BaseStorageRepository {
  final FirebaseStorage storage = FirebaseStorage.instance;

  @override
  Future<void> uploadImage(XFile image) async {
    try {
      await storage
          .ref('profile_pics/${image.name}')
          .putFile(
            File(image.path),
          )
          .then((p0) => DatabaseRepository().updateUserPicture(image.name));
    } catch (_) {}
  }

  @override
  Future<String> getDownloadUrl(String imageName) async {
    String downloadURL =
        await storage.ref('profile_pics/$imageName').getDownloadURL();

    return downloadURL;
  }
}
