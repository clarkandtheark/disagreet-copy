import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/helperfunctions.dart';
import 'package:disagreet_flutter/services/auth.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/views/forgotpassword.dart';
import 'package:disagreet_flutter/views/mainPage.dart';
import 'package:disagreet_flutter/widget/buttons.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class SignIn extends StatefulWidget {
  final Function toggle;
  const SignIn(this.toggle);

  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  final formKey = GlobalKey<FormState>();
  bool isLoading = false;
  bool wrongInfo = false;
  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();
  AuthMethods authMethods = AuthMethods();
  DatabaseMethods databaseMethods = DatabaseMethods();
  late QuerySnapshot snapshotUserInfo;

  signMeIn() {
    if (formKey.currentState!.validate()) {
      setState(() {
        wrongInfo = false;
        isLoading = true;
      });
      authMethods
          .signInWithEmail(emailTextEditingController.text,
              passwordTextEditingController.text)!
          .then((val) {
        if (val != null) {
          databaseMethods
              .getUserByUserEmail(emailTextEditingController.text)
              .then((val) {
            snapshotUserInfo = val;
            HelperFunctions.saveUserInfo(
                    firstName: snapshotUserInfo.docs[0]["firstName"],
                    lastName: snapshotUserInfo.docs[0]["lastName"],
                    uid: snapshotUserInfo.docs[0].id,
                    email: snapshotUserInfo.docs[0]["email"],
                    imageUrl: snapshotUserInfo.docs[0]["imageUrl"],
                    login: true)
                .then((val) {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const MainPage(startingIndex: 0)));
            });
          });
        } else {
          setState(() {
            wrongInfo = true;
            isLoading = false;
          });
        }
      });
    }
  }

  googleSignIn() {
    authMethods.signInWithGoogle(context);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: appBarMain(context, "Sign In") as PreferredSizeWidget,
        body: isLoading
            ? const Center(
                child: CircularProgressIndicator(
                strokeWidth: 6,
              ))
            : SingleChildScrollView(
                child: Container(
                  height: MediaQuery.of(context).size.height - 50,
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Form(
                          key: formKey,
                          child: Column(
                            children: [
                              TextFormField(
                                  controller: emailTextEditingController,
                                  validator: (val) {
                                    return RegExp(
                                                r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                            .hasMatch(val!)
                                        ? null
                                        : "Please enter a valid email";
                                  },
                                  style: simpleTextStyle(),
                                  decoration:
                                      textFieldInputDecoration("Email")),
                              TextFormField(
                                controller: passwordTextEditingController,
                                validator: (val) {
                                  return val!.isEmpty || val.length < 8
                                      ? "Password must be at least 8 characters in length"
                                      : null;
                                },
                                obscureText: true,
                                style: simpleTextStyle(),
                                decoration:
                                    textFieldInputDecoration("Password"),
                              ),
                            ],
                          )),
                      const SizedBox(
                        height: 8,
                      ),
                      wrongInfo
                          ? Row(
                              children: [
                                Container(
                                    padding: const EdgeInsets.only(right: 4),
                                    child: Icon(Icons.error,
                                        color: Colors.red[600])),
                                Flexible(
                                  child: Text(
                                      "Wrong email or password. Try again of click Forgot Password to reset it.",
                                      style: TextStyle(color: Colors.red[600])),
                                ),
                              ],
                            )
                          : const SizedBox(),
                      GestureDetector(
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ForgotPassword())),
                        child: Container(
                            alignment: Alignment.centerRight,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 8),
                              child: Text(
                                "Forgot Password?",
                                style: simpleTextStyle(),
                              ),
                            )),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      GestureDetector(
                        onTap: () => signMeIn(),
                        child: const PurpleButton("Sign In"),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      GestureDetector(
                          onTap: () => googleSignIn(),
                          child: const GoogleButton("Sign In With Google")),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Don't have an account? ",
                              style: mediumTextStyle(),
                            ),
                            GestureDetector(
                              onTap: () {
                                widget.toggle();
                              },
                              child: Container(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8),
                                child: const Text(
                                  "Register here",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 17,
                                      decoration: TextDecoration.underline),
                                ),
                              ),
                            ),
                          ]),
                      const SizedBox(height: 100)
                    ]),
                  ),
                ),
              ),
      ),
    );
  }
}
