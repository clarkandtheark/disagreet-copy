import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/services/auth.dart';
import 'package:disagreet_flutter/widget/buttons.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:disagreet_flutter/views/onboarding/widgets/widgets.dart';
import 'dart:math';

class Home extends StatefulWidget {
  Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final AuthMethods authMethods = AuthMethods();
  DatabaseMethods databaseMethods = DatabaseMethods();
  double? civilRating;
  double? listenRating;
  double? fallacyRating;
  double? overallRating;

  double roundDouble(double value, int places) {
    num mod = pow(10.0, places);
    return ((value * mod).round().toDouble() / mod);
  }

  computeRating() async {
    civilRating = roundDouble(
        await databaseMethods.getAverageRatingByTopic("Civility"), 1);
    listenRating =
        roundDouble(await databaseMethods.getAverageRatingByTopic("Listen"), 1);
    fallacyRating = roundDouble(
        await databaseMethods.getAverageRatingByTopic("Fallacies"), 1);
    overallRating =
        roundDouble((civilRating! + listenRating! + fallacyRating!) / 3, 1);
    return ("hi");
  }

  @override
  Widget build(BuildContext context) {
    return Builder(builder: (context) {
      return FutureBuilder(
          future: computeRating(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            Widget scaffold;
            if (snapshot.hasData) {
              scaffold = Scaffold(
                  appBar: appBarLogout(
                          context, authMethods.signOut, "Disagreet", false)
                      as PreferredSizeWidget,
                  body: SingleChildScrollView(
                    child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 25.0, vertical: 25),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Center(
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      CustomTextHeader(
                                          text: 'Hi ${Constants.myFirstName}!'),
                                      SizedBox(height: 25),
                                      Text(
                                        "Your overall chat rating is ${overallRating}",
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline6!
                                            .copyWith(height: 1.8),
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 10),
                                      displayStarRating(overallRating!),
                                      SizedBox(height: 40),
                                      Text(
                                        "Rating Breakdown",
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline4!
                                            .copyWith(height: 1.8),
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 25),
                                      Text(
                                        "Your average listening rating is ${listenRating}",
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline6!
                                            .copyWith(height: 1.8),
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 10),
                                      displayStarRating(listenRating!),
                                      SizedBox(height: 25),
                                      Text(
                                        "Your average civil rating is ${civilRating}",
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline6!
                                            .copyWith(height: 1.8),
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 10),
                                      displayStarRating(civilRating!),
                                      SizedBox(height: 25),
                                      Text(
                                        "Your average fallacy rating is ${fallacyRating}",
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline6!
                                            .copyWith(height: 1.8),
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(height: 10),
                                      displayStarRating(fallacyRating!),
                                    ]),
                              )
                            ])),
                  ));
            } else if (snapshot.hasError) {
              scaffold = Scaffold(
                  appBar: appBarLogout(
                          context, authMethods.signOut, "Disagreet", false)
                      as PreferredSizeWidget,
                  body: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 25.0, vertical: 25),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            SingleChildScrollView(
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                  CustomTextHeader(
                                      text: 'Hi ${Constants.myFirstName}!'),
                                  SizedBox(height: 25),
                                  Text(
                                    "Looks like you haven't finished any conversations yet. Get chatting!",
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6!
                                        .copyWith(height: 1.8),
                                    textAlign: TextAlign.center,
                                  )
                                ]))
                          ])));
            } else {
              scaffold = Scaffold(
                appBar: appBarLogout(
                        context, authMethods.signOut, "Choose a Topic", false)
                    as PreferredSizeWidget,
                body: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: CircularProgressIndicator(),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 16),
                        child: Text('Awaiting result...'),
                      )
                    ],
                  ),
                ),
              );
            }
            return scaffold;
          });
    });
  }
}
