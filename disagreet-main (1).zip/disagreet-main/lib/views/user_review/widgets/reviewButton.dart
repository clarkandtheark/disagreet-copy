import 'package:flutter/material.dart';
import 'package:disagreet_flutter/services/database.dart';

class ReviewButton extends StatelessWidget {
  final TabController tabController;
  final String text;
  final String fullName;
  final String otherUserID;
  final String type;
  final int rating;

  ReviewButton(
      {Key? key,
      required this.tabController,
      required this.text,
      required this.fullName,
      required this.otherUserID,
      required this.rating,
      required this.type})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    DatabaseMethods databaseMethods = DatabaseMethods();
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        gradient: LinearGradient(
          colors: [
            Theme.of(context).colorScheme.secondary,
            Theme.of(context).primaryColor,
          ],
        ),
      ),
      child: ElevatedButton(
        onPressed: () {
          tabController.animateTo(tabController.index + 1);
          databaseMethods.updateRating(rating, otherUserID, type);
        },
        style: ElevatedButton.styleFrom(
          primary: Colors.transparent,
          elevation: 0,
        ),
        child: Container(
          width: double.infinity,
          child: Center(
            child: Text(
              text,
              style: Theme.of(context)
                  .textTheme
                  .headline4!
                  .copyWith(color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}
