import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:disagreet_flutter/signup/signup_cubit.dart';
import 'package:disagreet_flutter/auth/auth_repository.dart';
import 'package:disagreet_flutter/widget/widget.dart';

import 'user_review_screens/screens.dart';

class UserReview extends StatelessWidget {
  static const String routeName = '/user_review';
  final String fullName;
  final String otherUserId;
  final String conversationId;
  const UserReview(this.otherUserId, this.fullName, this.conversationId);

  Route route() {
    return MaterialPageRoute(
        settings: RouteSettings(name: routeName),
        builder: (context) =>
            UserReview(otherUserId, fullName, conversationId));
  }

  static const List<Tab> tabs = <Tab>[
    Tab(text: 'Start'),
    Tab(text: 'Listen'),
    Tab(text: 'Civility'),
    Tab(text: 'Fallacies')
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabs.length,
      child: Builder(builder: (BuildContext context) {
        final TabController tabController = DefaultTabController.of(context)!;
        tabController.addListener(() {
          if (!tabController.indexIsChanging) {}
        });
        return Scaffold(
          appBar: appBarMain(context, "Disagreet") as PreferredSizeWidget,
          body: TabBarView(
            children: [
              StartReview(
                tabController: tabController,
                fullName: fullName,
                otherUserID: otherUserId,
              ),
              Listen(
                  tabController: tabController,
                  fullName: fullName,
                  otherUserID: otherUserId),
              Civility(
                  tabController: tabController,
                  fullName: fullName,
                  otherUserID: otherUserId),
              Fallacies(
                  tabController: tabController,
                  fullName: fullName,
                  otherUserID: otherUserId,
                  conversationId: conversationId),
            ],
          ),
        );
      }),
    );
  }
}
