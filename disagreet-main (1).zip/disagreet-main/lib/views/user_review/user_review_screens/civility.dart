import 'package:disagreet_flutter/views/user_review/widgets/reviewButton.dart';
import 'package:flutter/material.dart';
import 'package:disagreet_flutter/views/onboarding/widgets/widgets.dart';
import 'package:disagreet_flutter/views/user_review/widgets/widgets.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';
import 'package:disagreet_flutter/services/database.dart';

class Civility extends StatefulWidget {
  final TabController tabController;
  final String fullName;
  final String otherUserID;

  const Civility(
      {Key? key,
      required this.tabController,
      required this.fullName,
      required this.otherUserID})
      : super(key: key);

  @override
  State<Civility> createState() => _CivilityState();
}

class _CivilityState extends State<Civility> {
  int _rating = 0;

  @override
  Widget build(BuildContext context) {
    final controller = TextEditingController();
    var fullName = widget.fullName;
    var otherUserID = widget.otherUserID;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 50),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomTextHeader(
                    text:
                        'How civil was ${fullName} during your conversation?'),
                SizedBox(height: 25),
                Text(
                  "Did they treat you with respect regardless of your opinions?",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .copyWith(height: 1.8),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 25),
                Rating((rating) {
                  setState(() {
                    _rating = rating;
                  });
                }, 5),
                SizedBox(
                    height: 44,
                    child: (_rating != null && _rating != 0)
                        ? Text("You selected $_rating rating",
                            style: TextStyle(fontSize: 30))
                        : SizedBox.shrink()),
              ],
            ),
          ),
          Expanded(child: Container()),
          SingleChildScrollView(
            child: Column(
              children: [
                StepProgressIndicator(
                  totalSteps: 4,
                  currentStep: 3,
                  selectedColor: Theme.of(context).primaryColor,
                  unselectedColor: Theme.of(context).backgroundColor,
                ),
                SizedBox(height: 10),
                ReviewButton(
                    tabController: widget.tabController,
                    text: "Next Step",
                    fullName: fullName,
                    otherUserID: otherUserID,
                    rating: _rating,
                    type: "Civility")
              ],
            ),
          ),
        ],
      ),
    );
  }
}
