import 'package:disagreet_flutter/views/user_review/widgets/reviewButton.dart';
import 'package:flutter/material.dart';
import 'package:disagreet_flutter/views/onboarding/widgets/widgets.dart';
import 'package:disagreet_flutter/views/user_review/widgets/widgets.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';
import 'package:disagreet_flutter/services/database.dart';

class Listen extends StatefulWidget {
  final TabController tabController;
  final String fullName;
  final String otherUserID;

  const Listen(
      {Key? key,
      required this.tabController,
      required this.fullName,
      required this.otherUserID})
      : super(key: key);

  @override
  State<Listen> createState() => _ListenState();
}

class _ListenState extends State<Listen> {
  int _rating = 0;

  @override
  Widget build(BuildContext context) {
    DatabaseMethods databaseMethods = DatabaseMethods();
    final controller = TextEditingController();
    var fullName = widget.fullName;
    var otherUserID = widget.otherUserID;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 50),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomTextHeader(
                    text: 'How good was ${fullName} at listening?'),
                SizedBox(height: 25),
                Text(
                  "Reminder: Listening to you isn't the same thing as agreeing with you",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .copyWith(height: 1.8),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 25),
                Rating((rating) {
                  setState(() {
                    _rating = rating;
                  });
                }, 5),
                SizedBox(
                    height: 44,
                    child: (_rating != null && _rating != 0)
                        ? Text("You selected $_rating rating",
                            style: TextStyle(fontSize: 30))
                        : SizedBox.shrink()),
              ],
            ),
          ),
          Expanded(child: Container()),
          SingleChildScrollView(
            child: Column(
              children: [
                StepProgressIndicator(
                  totalSteps: 4,
                  currentStep: 2,
                  selectedColor: Theme.of(context).primaryColor,
                  unselectedColor: Theme.of(context).backgroundColor,
                ),
                SizedBox(height: 10),
                ReviewButton(
                    tabController: widget.tabController,
                    text: "Next Step",
                    fullName: fullName,
                    otherUserID: otherUserID,
                    rating: _rating,
                    type: "Listen")
              ],
            ),
          ),
        ],
      ),
    );
  }
}
