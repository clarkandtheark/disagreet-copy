import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:flutter/material.dart';
import 'package:disagreet_flutter/views/onboarding/widgets/widgets.dart';
import 'package:disagreet_flutter/views/user_review/widgets/widgets.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';
import 'package:disagreet_flutter/views/mainPage.dart';
import 'package:disagreet_flutter/widget/buttons.dart';
import 'package:disagreet_flutter/services/database.dart';

class Fallacies extends StatefulWidget {
  final TabController tabController;
  final String fullName;
  final String otherUserID;
  final String conversationId;

  const Fallacies(
      {Key? key,
      required this.tabController,
      required this.fullName,
      required this.otherUserID,
      required this.conversationId})
      : super(key: key);

  @override
  State<Fallacies> createState() => _FallaciesState();
}

class _FallaciesState extends State<Fallacies> {
  int _rating = 0;
  DatabaseMethods databaseMethods = DatabaseMethods();

  @override
  Widget build(BuildContext context) {
    final controller = TextEditingController();
    var fullName = widget.fullName;
    var otherUserID = widget.otherUserID;
    DatabaseMethods databaseMethods = DatabaseMethods();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 50),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomTextHeader(
                    text:
                        'How good was ${fullName} at avoiding the use of logical fallacies?'),
                SizedBox(height: 25),
                Text(
                  "Did the conversation stay fact-based, or did examples get out of control?",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .copyWith(height: 1.8),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 25),
                Rating((rating) {
                  setState(() {
                    _rating = rating;
                  });
                }, 5),
                SizedBox(
                    height: 44,
                    child: (_rating != null && _rating != 0)
                        ? Text("You selected $_rating rating",
                            style: TextStyle(fontSize: 12))
                        : SizedBox.shrink()),
              ],
            ),
          ),
          Expanded(child: Container()),
          SingleChildScrollView(
            child: Column(
              children: [
                StepProgressIndicator(
                  totalSteps: 4,
                  currentStep: 4,
                  selectedColor: Theme.of(context).primaryColor,
                  unselectedColor: Theme.of(context).backgroundColor,
                ),
                SizedBox(height: 10),
                GestureDetector(
                  onTap: () async {
                    String convoStatus = await databaseMethods.getConversationStatus(widget.conversationId);
                    String newStatus = '';
                    if(convoStatus == "pendingRating"){
                      newStatus = 'finished';
                    } else {
                      newStatus = "pendingRating";
                    }

                    await databaseMethods.requestConversationEnd(
                        widget.conversationId, newStatus, widget.fullName);
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MainPage(
                                  startingIndex: 0,
                                )));
                  },
                  child: PurpleButton("Finish Review"),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
