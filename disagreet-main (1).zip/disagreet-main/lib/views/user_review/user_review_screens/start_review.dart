import 'package:flutter/material.dart';
import 'package:disagreet_flutter/views/onboarding/widgets/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

class StartReview extends StatelessWidget {
  final TabController tabController;
  final String fullName;
  final String otherUserID;

  const StartReview(
      {Key? key,
      required this.tabController,
      required this.fullName,
      required this.otherUserID})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 50),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              // Container(
              //   height: 200,
              //   width: 200,
              //   child: SvgPicture.asset(
              //     'assets/disagreet.svg',
              //   ),
              // ),
              // SizedBox(height: 50),
              Text(
                'Leave a Review',
                style: Theme.of(context).textTheme.headline3,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              Text(
                'As you honestly review those you have conversations with, Disagreet is able to keep our user base full of people truly seeking to learn from one another. Please take the time now to review your conversation with ${fullName}. You will be asked specific questions as to how they were in terms of being polite and providing good conversation, you should not review based on their final position on a topic.',
                style: Theme.of(context)
                    .textTheme
                    .bodyText1!
                    .copyWith(height: 1.8),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          CustomButton(tabController: tabController, text: 'START')
        ],
      ),
    );
  }
}
