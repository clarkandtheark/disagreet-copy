import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/models/topic_model.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/widget/topicForm.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class TopicDefine extends StatefulWidget {
  // TopicDefine({Key key}) : super(key: key);

  final QueryDocumentSnapshot<Object?> topicInfo;

  const TopicDefine(this.topicInfo);

  @override
  _TopicDefineState createState() {
    return _TopicDefineState();
  }
}

class _TopicDefineState extends State<TopicDefine> {
  final DatabaseMethods databaseMethods = DatabaseMethods();
  var stanceNum = 0.0;
  var stanceEntry = '';

  Future<String> getTopic() async {
    var userInfo = await databaseMethods.getTopicUserById(
        widget.topicInfo.id, Constants.myUid);
    try {
      if (userInfo.exists) {
        stanceNum = userInfo["stanceNum"];
        stanceEntry = userInfo["stanceEntry"];
        return "Data loaded";
      }
    } catch (e) {
      return "No Data Loaded";
    }
    return "Text";
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: getTopic(),
        builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: Scaffold(
                  appBar: appBarMain(context, widget.topicInfo["name"])
                      as PreferredSizeWidget,
                  body: Column(children: [
                    titleSection(),
                    descriptionSection(),
                    surveySection()
                  ])),
            );
          } else {
            return Scaffold(
              appBar: appBarMain(context, widget.topicInfo["name"])
                  as PreferredSizeWidget,
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    SizedBox(
                      width: 60,
                      height: 60,
                      child: CircularProgressIndicator(),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: Text('Awaiting result...'),
                    )
                  ],
                ),
              ),
            );
          }
        });
  }

  Widget titleSection() {
    return Container(
      padding: const EdgeInsets.all(32),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    "Let's talk about " + widget.topicInfo["name"],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 32,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget descriptionSection() {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Text(widget.topicInfo["description"] as String, softWrap: true),
    );
  }

  Widget surveySection() {
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Column(
              children: [
                TopicForm(
                  stanceNum: stanceNum,
                  stanceEntry: stanceEntry,
                  topic: Topic(
                    id: widget.topicInfo.id,
                    topicName: widget.topicInfo['name'],
                    description: widget.topicInfo['description'],
                    pro: widget.topicInfo['pro'],
                    con: widget.topicInfo['con'],
                    peopleTalking: widget.topicInfo['peopleTalking'],
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
