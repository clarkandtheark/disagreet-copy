import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/views/user_review/user_review.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/widget/messageTile.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:disagreet_flutter/views/mainPage.dart';

class ChatView extends StatefulWidget {
  final bool editable;
  final String conversationId;
  final String topic;
  final String fullName;
  const ChatView(this.conversationId, this.topic, this.fullName, this.editable);

  @override
  _ChatViewState createState() {
    return _ChatViewState();
  }
}

class _ChatViewState extends State<ChatView> {
  DatabaseMethods databaseMethods = DatabaseMethods();
  TextEditingController messageController = TextEditingController();

  Stream? chatMessagesStream;
  String? requesterName;
  String? conversationStatus;
  String? dialogStatus;

  Widget ChatMessageList() {
    return StreamBuilder(
      stream: chatMessagesStream!,
      builder: (context, AsyncSnapshot snapshot) {
        // TODO: if !inProgress, add
        return snapshot.hasData
            ? ListView.builder(
                shrinkWrap: true,
                itemCount: snapshot.data.docs.length,
                itemBuilder: (context, index) {
                  return MessageTile(
                      snapshot.data.docs[index]["message"],
                      snapshot.data.docs[index]["sendBy"] ==
                          Constants.myFirstName);
                })
            : Container();
      },
    );
  }

  @override
  void dispose() {
    super.dispose();
  }

  sendMessage() async {
    if (messageController.text.isNotEmpty) {
      Map<String, dynamic> messageMap = {
        "message": messageController.text,
        "sendBy": Constants.myFirstName,
        "time": DateTime.now()
      };
      messageController.clear();
      await databaseMethods.addConversationMessage(
          widget.conversationId, messageMap);
      await databaseMethods.updateLatestMessage(
          widget.conversationId, messageMap);
    }
  }

  @override
  void initState() {
    databaseMethods.getConversationMessage(widget.conversationId).then((value) {
      setState(() {
        chatMessagesStream = value;
      });
    });

    databaseMethods.getRequesterName(widget.conversationId).then((value) {
      setState(() {
        requesterName = value;
      });
    });
    databaseMethods.getConversationStatus(widget.conversationId).then((value) {
      setState(() {
        conversationStatus = value;
        if (value == 'inProgress') {
          dialogStatus = 'inProgress';
        } else if (value == 'finished') {
          dialogStatus = 'finished';
        } else if (value == 'requestWrapup' &&
            requesterName == widget.fullName) {
          dialogStatus = 'acceptEndRequest';
        } else if (value == 'requestWrapup' &&
            requesterName != widget.fullName) {
          dialogStatus = 'cancelEndRequest';
        } else if (value == 'reportAbuse' && requesterName == widget.fullName) {
          dialogStatus = 'requestArbitration';
        } else if (value == 'reportAbuse' && requesterName != widget.fullName) {
          dialogStatus = 'cancelEndRequest';
        } else if (value == 'pendingRating') {
          dialogStatus = 'pendingRating';
        } else if (value == 'requestArbitration') {
          dialogStatus = 'staffReview';
        }
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    List<String> ids = widget.conversationId.split('_');
    String otherUserId = ids[0] == Constants.myUid ? ids[1] : ids[0];

    Map<String, dynamic> dialogMap = {
      "inProgress": {
        "title": "Done chatting?",
        "description":
            "Send a request to your co-disagreeter to wrap up the chat, or report abuse and our staff will review your request.",
        "cancelButton": FlatButton(
          color: Colors.red,
          textColor: Colors.white,
          onPressed: () => Navigator.pop(context),
          child: const Text('Report Abuse'),
        ),
        "confirmButton": FlatButton(
          color: Colors.green,
          textColor: Colors.white,
          onPressed: () async => {
            await databaseMethods.requestConversationEnd(
                widget.conversationId,
                "requestWrapup",
                Constants.myFirstName + " " + Constants.myLastName),
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => MainPage(startingIndex: 2)))
          },
          child: const Text('Request Wrap-up'),
        ),
      },
      "acceptEndRequest": {
        "title": "A request has been made...",
        "description": widget.fullName +
            " is ready to finish chatting. Are you? If so, accept the wrapup request, otherwise request an arbitration and one of our staff members will see what's up",
        "cancelButton": FlatButton(
          color: Colors.red,
          textColor: Colors.white,
          onPressed: () => Navigator.pop(context),
          child: const Text('Request Arbitration'),
        ),
        "confirmButton": FlatButton(
          color: Colors.green,
          textColor: Colors.white,
          onPressed: () async => {
            await databaseMethods.requestConversationEnd(
                widget.conversationId, "pendingRating", widget.fullName),
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => UserReview(
                        otherUserId, widget.fullName, widget.conversationId)))
          },
          child: const Text('Accept Request'),
        ),
      },
      "requestArbitration": {
        "title": "Pending Resolution",
        "description":
            "A request has been made to review this conversation. Please wait while we review the conversation.",
        "cancelButton": Container(),
        "confirmButton": Container()
      },
      "cancelEndRequest": {
        "title": "Cancel Request?",
        "description":
            "Wrapped things up too soon? No worries. Cancel your request to continue chatting.",
        "cancelButton": FlatButton(
          color: Colors.red[200],
          textColor: Colors.white,
          onPressed: () async => {
            await databaseMethods.requestConversationEnd(
                widget.conversationId, "inProgress", ""),
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Container()))
          },
          child: const Text('Cancel Request'),
        ),
        "confirmButton": Container()
      },
      "finished": {
        "title": "All done!",
        "description":
            "This conversation has finished. Go disagreet somewhere else!",
        "cancelButton": Container(),
        "confirmButton": Container(),
      },
      "pendingRating": {
        "title": "Time to rate!",
        "description":
            "Now that your conversation is over, please go rate the other person! This helps you, them, and the community.",
        "cancelButton": Container(),
        "confirmButton": FlatButton(
          color: Colors.green,
          textColor: Colors.white,
          onPressed: () async => {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => UserReview(
                        otherUserId, widget.fullName, widget.conversationId)))
          },
          child: Text('Rate ' + widget.fullName),
        ),
      }
    };

    conversationDialog(String conversationStatus) {
      return AlertDialog(
        titlePadding: const EdgeInsetsDirectional.only(start: 24, top: 8),
        title: Row(children: [
          Text(dialogMap[dialogStatus]["title"]),
          Spacer(),
          FlatButton(
            textColor: Colors.deepPurple,
            onPressed: () => Navigator.pop(context),
            child: const Icon(Icons.close),
          ),
        ]),
        content: Text(dialogMap[dialogStatus]["description"]),
        actions: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            dialogMap[dialogStatus]["cancelButton"],
            const Spacer(),
            dialogMap[dialogStatus]["confirmButton"],
          ])
        ],
      );
    }

    WidgetsBinding.instance!.addPostFrameCallback((_) {
      if (conversationStatus == 'pendingRating' &&
          requesterName !=
              (Constants.myFirstName + " " + Constants.myLastName)) {
        List<String> ids = widget.conversationId.split('_');
        String otherUserId = ids[0] == Constants.myUid ? ids[1] : ids[0];
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => UserReview(
                    otherUserId, widget.fullName, widget.conversationId)));
      }
    });

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: appBarWithButton(
            context,
            "${widget.topic} - ${widget.fullName}",
            IconButton(
              onPressed: () {
                showDialog<void>(
                    context: context,
                    builder: (context) => conversationDialog("inProgress"));
              },
              icon: const Icon(Icons.thumbs_up_down),
              color: Colors.white,
            )) as PreferredSizeWidget,
        body: Container(
          height: MediaQuery.of(context).size.height * .9,
          child: Column(
            children: [
              Expanded(child: ChatMessageList()),
              ['inProgress', 'finished'].contains(conversationStatus)
                  ? Container()
                  : Container(
                      alignment: Alignment.center,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            textStyle: const TextStyle(color: Colors.white),
                            primary: Colors.deepPurpleAccent,
                            shadowColor: Colors.black),
                        onPressed: () {},
                        child: const Text(
                          "A request has been made to end this conversation",
                        ),
                      )),
              widget.editable
                  ? Container(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        height: MediaQuery.of(context).size.height * 0.1,
                        color: Colors.white,
                        padding: const EdgeInsets.only(
                            left: 24, right: 24, bottom: 30),
                        // padding: const EdgeInsets.symmetric(
                        //     horizontal: 24, vertical: 0),
                        child: Row(
                          children: [
                            Expanded(
                                child: Container(
                              color: Colors.white,
                              child: TextField(
                                  controller: messageController,
                                  minLines: 1,
                                  maxLines: 5,
                                  style: const TextStyle(color: Colors.black),
                                  decoration: const InputDecoration(
                                      hintText: "Message...",
                                      hintStyle:
                                          TextStyle(color: Colors.black38))),
                            )),
                            GestureDetector(
                              onTap: () {
                                sendMessage();
                              },
                              child: Container(
                                  height: 40,
                                  width: 40,
                                  decoration: BoxDecoration(
                                      gradient: const LinearGradient(colors: [
                                        Color(0x36FFFFFF),
                                        Color(0x0FFFFFFF)
                                      ]),
                                      borderRadius: BorderRadius.circular(40)),
                                  padding: const EdgeInsets.all(12),
                                  child: const Icon(Icons.send)),
                            ),
                          ],
                        ),
                      ),
                    )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }
}
