import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/services/auth.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/widget/ConversationTile.dart';
import 'package:disagreet_flutter/views/search.dart';
import 'package:disagreet_flutter/widget/RequestTile.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class ChatList extends StatefulWidget {
  const ChatList({Key? key}) : super(key: key);

  @override
  _ChatListState createState() => _ChatListState();
}

class _ChatListState extends State<ChatList> {
  AuthMethods authMethods = AuthMethods();
  DatabaseMethods databaseMethods = DatabaseMethods();

  Stream<QuerySnapshot>? conversationsStream;

  Widget conversationList() {
    return StreamBuilder(
        stream: conversationsStream,
        builder: (context, AsyncSnapshot snapshot) {
          return DefaultTabController(
            length: 3,
            child: Scaffold(
              appBar: appBarLogout(
                      context, authMethods.signOut, "Conversations", true)
                  as PreferredSizeWidget,
              body: TabBarView(
                children: [
                  snapshot.hasData
                      ? ListView.builder(
                          itemCount: snapshot.data.docs.length,
                          itemBuilder: (context, index) {
                            var position = snapshot.data.docs[index]["names"]
                                        [0] ==
                                    "${Constants.myFirstName} ${Constants.myLastName}"
                                ? 1
                                : 0;
                            if (!["inProgress", "requestWrapup", "pendingRating"].contains(snapshot.data.docs[index]["status"])
                                ) {
                              return Container();
                            } else {
                              return ConversationTile(
                                topic: snapshot.data.docs[index]["topic"],
                                fullName: snapshot.data.docs[index]["names"]
                                    [position],
                                id: snapshot.data.docs[index].id,
                                latestMessageMap: snapshot.data.docs[index]
                                    ["latestMessage"],
                                inProgress: snapshot.data.docs[index]["status"] == "inProgress",
                                imageUrl: snapshot.data.docs[index]["imageUrls"]
                                        [position] ??
                                    "",
                              );
                            }
                          })
                      : Container(),
                  snapshot.hasData
                      ? ListView.builder(
                          itemCount: snapshot.data.docs.length,
                          itemBuilder: (context, index) {
                            var position = snapshot.data.docs[index]["names"]
                                        [0] ==
                                    "${Constants.myFirstName} ${Constants.myLastName}"
                                ? 1
                                : 0;
                            if (snapshot.data.docs[index]["status"] !=
                                "requestSent") {
                              return Container();
                            } else {
                              return RequestTile(
                                messageId: snapshot.data.docs[index].id,
                                topic: snapshot.data.docs[index]["topic"],
                                fullName: snapshot.data.docs[index]["names"]
                                    [position],
                                latestMessageMap: snapshot.data.docs[index]
                                    ["latestMessage"],
                                imageUrl: snapshot.data.docs[index]["imageUrls"]
                                    [position],
                              );
                            }
                          })
                      : Container(),
                  snapshot.hasData
                      ? ListView.builder(
                          itemCount: snapshot.data.docs.length,
                          itemBuilder: (context, index) {
                            var position = snapshot.data.docs[index]["names"]
                                        [0] ==
                                    "${Constants.myFirstName} ${Constants.myLastName}"
                                ? 1
                                : 0;
                            if (snapshot.data.docs[index]["status"] !=
                                "finished") {
                              return Container();
                            } else {
                              return ConversationTile(
                                topic: snapshot.data.docs[index]["topic"],
                                fullName: snapshot.data.docs[index]["names"]
                                    [position],
                                id: snapshot.data.docs[index].id,
                                latestMessageMap: snapshot.data.docs[index]
                                    ["latestMessage"],
                                inProgress: false,
                                imageUrl: snapshot.data.docs[index]["imageUrls"]
                                    [position],
                              );
                            }
                          },
                        )
                      : Container(),
                ],
              ),
            ),
          );
        });
  }

  @override
  void initState() {
    getUserInfo();
    super.initState();
  }

  getUserInfo() async {
    databaseMethods.getConversations(Constants.myUid).then((value) {
      setState(() {
        conversationsStream = value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: conversationList(),
      floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.search),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const SearchScreen()));
          }),
    );
  }
}
