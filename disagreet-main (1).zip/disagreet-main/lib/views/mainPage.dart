import 'package:disagreet_flutter/services/auth.dart';
import 'package:disagreet_flutter/views/chatList.dart';
import 'package:disagreet_flutter/views/topics.dart';
import 'package:disagreet_flutter/views/home.dart';
import 'package:flutter/material.dart';

class MainPage extends StatefulWidget {
  final int startingIndex;
  const MainPage({required this.startingIndex});

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  AuthMethods authMethods = AuthMethods();
  int _selectedIndex = 0;

  @override
  void initState() {
    // TODO: implement initState
    _selectedIndex = widget.startingIndex;
    super.initState();
  }

  void _onItemTapped(index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  final List<Widget> _pages = [
    Home(),
    TopicPage(),
    const ChatList(),
  ];

  final List<String> _titles = [
    "Disagreet",
    "Choose a Topic",
    "Conversations",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages.elementAt(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.explore),
            label: "Explore",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.message),
            label: "Messages",
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
