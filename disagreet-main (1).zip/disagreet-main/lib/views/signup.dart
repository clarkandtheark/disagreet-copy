import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/helperfunctions.dart';
import 'package:disagreet_flutter/services/auth.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/views/mainPage.dart';
import 'package:disagreet_flutter/views/onboarding/onboarding_screen.dart';
import 'package:disagreet_flutter/widget/buttons.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class SignUp extends StatefulWidget {
  final Function toggle;
  const SignUp(this.toggle);

  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  AuthMethods authMethods = AuthMethods();
  DatabaseMethods databaseMethods = DatabaseMethods();

  final formKey = GlobalKey<FormState>();
  String? passwordValidator;
  bool isLoading = false;

  TextEditingController firstNameTextEditingController =
      TextEditingController();
  TextEditingController lastNameTextEditingController = TextEditingController();
  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();
  TextEditingController confirmPasswordTextEditingController =
      TextEditingController();

  signMeUp() async {
    DocumentReference documentReference;
    if (formKey.currentState!.validate()) {
      Map<String, String> userInfoMap = {
        "firstName": firstNameTextEditingController.text,
        "lastName": lastNameTextEditingController.text,
        "email": emailTextEditingController.text
      };

      setState(() {
        isLoading = true;
      });
      await authMethods.signUpWithEmail(
          emailTextEditingController.text, passwordTextEditingController.text)!;
      documentReference = await databaseMethods.uploadUserInfo(userInfoMap);
      await HelperFunctions.saveUserInfo(
          firstName: firstNameTextEditingController.text,
          lastName: lastNameTextEditingController.text,
          uid: documentReference.id,
          email: emailTextEditingController.text,
          login: true);
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => OnboardingScreen()));
    }
  }

  googleSignUp() {
    authMethods.signInWithGoogle(context);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: appBarMain(context, "Sign Up") as PreferredSizeWidget,
        body: isLoading
            ? const Center(
                child: CircularProgressIndicator(
                strokeWidth: 6,
              ))
            : SingleChildScrollView(
                child: Container(
                  height: MediaQuery.of(context).size.height - 50,
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Form(
                        key: formKey,
                        child: Column(
                          children: [
                            TextFormField(
                                controller: firstNameTextEditingController,
                                validator: (val) {
                                  return val!.isEmpty
                                      ? "Please enter your first name"
                                      : null;
                                },
                                style: simpleTextStyle(),
                                decoration:
                                    textFieldInputDecoration("First Name")),
                            TextFormField(
                                controller: lastNameTextEditingController,
                                validator: (val) {
                                  return val!.isEmpty
                                      ? "Please enter your last name"
                                      : null;
                                },
                                style: simpleTextStyle(),
                                decoration:
                                    textFieldInputDecoration("Last Name")),
                            TextFormField(
                                controller: emailTextEditingController,
                                validator: (val) {
                                  return RegExp(
                                              r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                          .hasMatch(val!)
                                      ? null
                                      : "Please enter a valid email";
                                },
                                style: simpleTextStyle(),
                                decoration: textFieldInputDecoration("Email")),
                            TextFormField(
                              controller: passwordTextEditingController,
                              obscureText: true,
                              validator: (val) {
                                setState(() {
                                  passwordValidator = val;
                                });
                                return val!.isEmpty || val.length < 8
                                    ? "Password must be at least 8 characters in length"
                                    : null;
                              },
                              style: simpleTextStyle(),
                              decoration: textFieldInputDecoration("Password"),
                            ),
                            TextFormField(
                              controller: confirmPasswordTextEditingController,
                              obscureText: true,
                              validator: (val) {
                                return val != passwordValidator
                                    ? "Passwords must match"
                                    : null;
                              },
                              style: simpleTextStyle(),
                              decoration:
                                  textFieldInputDecoration("Confirm Password"),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      GestureDetector(
                        onTap: () => signMeUp(),
                        child: const PurpleButton("Sign Up"),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      GestureDetector(
                          onTap: () => googleSignUp(),
                          child: const GoogleButton("Sign Up With Google")),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Already have an account? ",
                              style: mediumTextStyle(),
                            ),
                            GestureDetector(
                              onTap: () => widget.toggle(),
                              child: Container(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8),
                                child: const Text(
                                  "Log in here",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 17,
                                      decoration: TextDecoration.underline),
                                ),
                              ),
                            ),
                          ]),
                      const SizedBox(height: 100)
                    ]),
                  ),
                ),
              ),
      ),
    );
  }
}
