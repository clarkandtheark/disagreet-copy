import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/services/auth.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/views/topicSearch.dart';
import 'package:disagreet_flutter/widget/topicCard.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class TopicPage extends StatefulWidget {
  @override
  _TopicPageState createState() => _TopicPageState();
}

class _TopicPageState extends State<TopicPage> {
  final DatabaseMethods databaseMethods = DatabaseMethods();
  final AuthMethods authMethods = AuthMethods();
  QuerySnapshot? topics;

  Future<String> getTopics() async {
    await databaseMethods.getAllTopics().then((value) {
      topics = value;
      return "Data Loaded";
    });
    return "Text";
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: getTopics(),
        builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
          Widget scaffold;
          if (snapshot.hasData) {
            scaffold = Scaffold(
              appBar: appBarLogout(
                      context, authMethods.signOut, "Choose a Topic", false)
                  as PreferredSizeWidget,
              body: GridView.count(
                crossAxisCount: 2,
                children: [
                  ...(topics!.docs).map((val) {
                    return TopicCard(val);
                  }).toList()
                ],
                padding: const EdgeInsets.all(10),
              ),
              floatingActionButton: FloatingActionButton(
                  child: const Icon(Icons.search),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const TopicSearch()));
                  }),
            );
          } else if (snapshot.hasError) {
            scaffold = Scaffold(
              appBar: appBarLogout(
                      context, authMethods.signOut, "Choose a Topic", false)
                  as PreferredSizeWidget,
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.error_outline,
                      color: Colors.red,
                      size: 60,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: Text('Error: ${snapshot.error}'),
                    )
                  ],
                ),
              ),
            );
          } else {
            scaffold = Scaffold(
              appBar: appBarLogout(
                      context, authMethods.signOut, "Choose a Topic", false)
                  as PreferredSizeWidget,
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    SizedBox(
                      width: 60,
                      height: 60,
                      child: CircularProgressIndicator(),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: Text('Awaiting result...'),
                    )
                  ],
                ),
              ),
            );
          }
          return scaffold;
        });
  }
}
