import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/models/topic_model.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/widget/matchTile.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:disagreet_flutter/models/stance_model.dart';
import 'package:flutter/scheduler.dart';

class MatchPage extends StatefulWidget {
  final double stanceNum;
  final Topic topicInfo;
  final String userInfoId;

  MatchPage(
      {required this.stanceNum,
      required this.topicInfo,
      required this.userInfoId});
  // MatchPage({Key key}) : super(key: key);

  @override
  _MatchPageState createState() {
    return _MatchPageState();
  }
}

class _MatchPageState extends State<MatchPage> {
  QuerySnapshot<Map<String, dynamic>>? theSnapshot;
  DatabaseMethods databaseMethods = DatabaseMethods();

  @override
  void initState() {
    super.initState();
    SchedulerBinding.instance!
        .addPostFrameCallback((timeStamp) => startDialog(context));
  }

  getStances() async {
    bool isPositive = widget.stanceNum > 0;

    theSnapshot = await databaseMethods.getTopicUserForMatching(
        widget.topicInfo.id, isPositive);
    return "Finished";
  }

  void startDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Center(
            child: Text(
          "Instructions",
          style: TextStyle(fontWeight: FontWeight.bold),
        )),
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              children: [
                Row(
                  children: const [
                    Icon(
                      Icons.keyboard_arrow_right_outlined,
                      size: 40,
                      color: Colors.deepPurple,
                    ),
                    Text(
                      "Swipe right to start talking",
                      style: TextStyle(fontSize: 16),
                    )
                  ],
                ),
                Row(
                  children: const [
                    Icon(
                      Icons.keyboard_arrow_left_outlined,
                      size: 40,
                      color: Colors.deepPurple,
                    ),
                    Text(
                      "Swipe left to move on.",
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Future.delayed(Duration.zero, () => startDialog(context));
    return Scaffold(
      appBar: appBarMain(context, "Match") as PreferredSizeWidget,
      body: Center(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * .9,
          height: MediaQuery.of(context).size.height * .7,
          child: FutureBuilder(
            future: getStances(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                return Stack(
                  children: [
                    const Center(
                      child: Text(
                        "You've gone through everybody! Come back later to match with new people",
                        style: TextStyle(
                          fontSize: 30,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    ...theSnapshot!.docs
                        .map(
                          (card) => MatchTile(
                            topic: widget.topicInfo,
                            stance: Stance(
                                fullName: card['fullName'],
                                id: card.id,
                                stanceEntry: card['stanceEntry'],
                                stanceNum: card['stanceNum'],
                                profileImage: card.data()["imageUrl"] ?? ""),
                          ),
                        )
                        .toList(),
                  ],
                );
              } else {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: CircularProgressIndicator(),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 16),
                        child: Text('Awaiting result...'),
                      )
                    ],
                  ),
                );
              }
            },
          ),
        ),
      ),
    );
  }
}
