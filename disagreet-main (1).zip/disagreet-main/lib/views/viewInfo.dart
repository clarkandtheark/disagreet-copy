import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class ViewInfo extends StatefulWidget {
  final QueryDocumentSnapshot<Object?> topicInfo;

  const ViewInfo(this.topicInfo);

  @override
  _ViewInfoState createState() => _ViewInfoState();
}

class _ViewInfoState extends State<ViewInfo> {
  TextEditingController nameController = TextEditingController();
  TextEditingController uidController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: appBarMain(context, widget.topicInfo["name"])
            as PreferredSizeWidget,
        body: Center(
          child: Column(
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  hintText: "Full name",
                ),
              ),
              TextField(
                controller: uidController,
                decoration: const InputDecoration(
                  hintText: "UID",
                ),
              ),
              ElevatedButton(
                  onPressed: () {
                    print("Hello!");
                  },
                  child: const Text("Push to ask for Conversation"))
            ],
          ),
        ));
  }
}
