import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/views/chatView.dart';
import 'package:disagreet_flutter/views/mainPage.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_bubble/bubble_type.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:flutter_chat_bubble/clippers/chat_bubble_clipper_2.dart';

List<String> images = [
  "https://www.jamsadr.com/images/neutrals/person-donald-900x1080.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/8/86/Joseph_Smith%2C_Jr._portrait_owned_by_Joseph_Smith_III.jpg",
  "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
  "https://marriott.byu.edu/msmadmin/securefile/empphoto?pid=25339",
];

String getRandomImage() {
  var random = Random();
  return images[random.nextInt(5)];
}

class RequestPage extends StatelessWidget {
  final String messageId;
  final String topic;
  final String fullName;
  final Map<String, dynamic> latestMessageMap;

  RequestPage(
      {required this.messageId,
      required this.topic,
      required this.fullName,
      required this.latestMessageMap});

  DocumentSnapshot? stanceSnapshot;
  QuerySnapshot? topicSnapshot;
  DatabaseMethods databaseMethods = DatabaseMethods();

  getReceiverView(CustomClipper clipper, BuildContext context) => ChatBubble(
        clipper: clipper,
        backGroundColor: const Color(0xffE7E7ED),
        margin: const EdgeInsets.only(top: 20),
        child: Container(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.7,
          ),
          child: Text(
            latestMessageMap['message'],
            style: const TextStyle(color: Colors.black),
          ),
        ),
      );

  getStance() async {
    String? uid;
    var idParts = messageId.split("_");
    idParts.removeLast();
    uid = idParts[0] == Constants.myUid ? idParts[1] : idParts[0];
    stanceSnapshot =
        await databaseMethods.getTopicUserById(topic.toLowerCase(), uid);
    topicSnapshot = await databaseMethods.getTopicByName(topic);
    return 'Finished';
  }

  messageAccepted(context) async {
    await databaseMethods.changeConversationStatus(messageId, "inProgress");
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => ChatView(messageId, topic, fullName, true),
      ),
    );
  }

  messageRejected(context) {
    databaseMethods.changeConversationStatus(messageId, "rejected");
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const MainPage(startingIndex: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarMain(context, "Request") as PreferredSizeWidget,
      body: FutureBuilder(
        future: getStance(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Center(
              child: Column(
                children: [
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 30),
                    alignment: Alignment.center,
                    height: MediaQuery.of(context).size.width * .4,
                    width: MediaQuery.of(context).size.width * .4,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: NetworkImage(stanceSnapshot!['imageUrl']),
                          fit: BoxFit.cover),
                      borderRadius: BorderRadius.circular(
                          MediaQuery.of(context).size.width * .4),
                    ),
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * .85,
                    child: Column(
                      children: [
                        Text(
                          stanceSnapshot!['fullName'],
                          style: const TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            stanceSnapshot!['stanceEntry'],
                            style: const TextStyle(fontSize: 18),
                          ),
                        ),
                        SliderTheme(
                          data: SliderThemeData(
                            activeTrackColor: Colors.deepPurple,
                            inactiveTrackColor: Colors.deepPurple,
                            thumbColor: Colors.grey.shade100,
                            trackShape: const RectangularSliderTrackShape(),
                          ),
                          child: Slider(
                            value: stanceSnapshot!['stanceNum'],
                            min: -10,
                            max: 10,
                            onChanged: (value) {},
                          ),
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * .8,
                          child: Row(
                            children: [
                              Text(
                                topicSnapshot!.docs[0]['con'],
                                style: const TextStyle(fontSize: 14),
                              ),
                              const Spacer(),
                              Text(
                                topicSnapshot!.docs[0]['pro'],
                                style: const TextStyle(fontSize: 14),
                              ),
                            ],
                          ),
                        ),
                        getReceiverView(
                            ChatBubbleClipper2(type: BubbleType.sendBubble),
                            context),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              margin: const EdgeInsets.only(
                                top: 40,
                              ),
                              height: MediaQuery.of(context).size.width * .25,
                              width: MediaQuery.of(context).size.width * .25,
                              child: Center(
                                child: GestureDetector(
                                  onTap: () => messageRejected(context),
                                  child: const Icon(
                                    Icons.close,
                                    size: 100,
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                                width: MediaQuery.of(context).size.width * 0.2),
                            Container(
                              margin: const EdgeInsets.only(top: 40),
                              height: MediaQuery.of(context).size.width * .25,
                              width: MediaQuery.of(context).size.width * .25,
                              child: Center(
                                child: GestureDetector(
                                  onTap: () => messageAccepted(context),
                                  child: const Icon(
                                    Icons.check,
                                    size: 100,
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }
}
