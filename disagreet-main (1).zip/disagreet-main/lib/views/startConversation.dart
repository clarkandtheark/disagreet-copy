import 'dart:math';

import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/helper/helperfunctions.dart';
import 'package:disagreet_flutter/models/stance_model.dart';
import 'package:disagreet_flutter/models/topic_model.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/widget/buttons.dart';
import 'package:disagreet_flutter/widget/emailConfirmation.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class StartConversation extends StatefulWidget {
  final String conversationId;
  final Topic topic;
  final Stance stance;

  const StartConversation(
      {required this.conversationId,
      required this.topic,
      required this.stance});

  @override
  State<StartConversation> createState() => _StartConversationState();
}

class _StartConversationState extends State<StartConversation> {
  TextEditingController messageController = TextEditingController();
  DatabaseMethods databaseMethods = DatabaseMethods();
  bool isLoading = false;
  bool messageSent = false;
  final formKey = GlobalKey<FormState>();

  sendMessageRequest() async {
    if (formKey.currentState!.validate()) {
      setState(() {
        isLoading = true;
      });
      var messageMap = {
        "message": messageController.text,
        "sendBy": Constants.myFirstName,
        "time": DateTime.now(),
      };
      var conversationMap = {
        "latestMessage": messageMap,
        "names": [
          "${Constants.myFirstName} ${Constants.myLastName}",
          widget.stance.fullName,
        ],
        "uids": [
          Constants.myUid,
          widget.stance.id.split("-")[1],
        ],
        "status": "requestSent",
        "topic": widget.topic.topicName,
        "imageUrls": [
          Constants.myImageUrl,
          widget.stance.profileImage,
        ]
      };
      await databaseMethods.createConversation(
          widget.conversationId, conversationMap);
      await databaseMethods.addConversationMessage(
          widget.conversationId, messageMap);
      setState(() {
        isLoading = false;
        messageSent = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: appBarMain(context, "Start Talking") as PreferredSizeWidget,
        body: messageSent
            ? const EmailConfirmation()
            : isLoading
                ? const Center(
                    child: CircularProgressIndicator(
                      strokeWidth: 6,
                    ),
                  )
                : SingleChildScrollView(
                    child: Center(
                      child: Column(
                        children: [
                          Container(
                              margin: const EdgeInsets.symmetric(vertical: 30),
                              alignment: Alignment.center,
                              height: MediaQuery.of(context).size.width * .4,
                              width: MediaQuery.of(context).size.width * .4,
                              decoration: widget.stance.profileImage == ""
                                  ? BoxDecoration(
                                      color: HelperFunctions.getRandomColor(
                                          widget.stance.fullName.hashCode),
                                      borderRadius: BorderRadius.circular(
                                          MediaQuery.of(context).size.width *
                                              .4),
                                    )
                                  : BoxDecoration(
                                      image: DecorationImage(
                                          image: NetworkImage(
                                              widget.stance.profileImage),
                                          fit: BoxFit.cover),
                                      borderRadius: BorderRadius.circular(
                                          MediaQuery.of(context).size.width *
                                              .4),
                                    ),
                              child: widget.stance.profileImage == ""
                                  ? Center(
                                      child: Text(
                                        widget.stance.fullName
                                                .split(" ")[0]
                                                .substring(0, 1) +
                                            widget.stance.fullName
                                                .split(" ")[1]
                                                .substring(0, 1),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 50,
                                        ),
                                      ),
                                    )
                                  : null),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * .85,
                            child: Column(
                              children: [
                                Text(
                                  widget.stance.fullName,
                                  style: const TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    widget.stance.stanceEntry,
                                    style: const TextStyle(fontSize: 18),
                                  ),
                                ),
                                SliderTheme(
                                  data: SliderThemeData(
                                    activeTrackColor: Colors.deepPurple,
                                    inactiveTrackColor: Colors.deepPurple,
                                    thumbColor: Colors.grey.shade100,
                                    trackShape:
                                        const RectangularSliderTrackShape(),
                                  ),
                                  child: Slider(
                                    value: widget.stance.stanceNum,
                                    min: -10,
                                    max: 10,
                                    onChanged: (value) {},
                                  ),
                                ),
                                SizedBox(
                                  width: MediaQuery.of(context).size.width * .8,
                                  child: Row(
                                    children: [
                                      Text(
                                        widget.topic.con,
                                        style: const TextStyle(fontSize: 14),
                                      ),
                                      const Spacer(),
                                      Text(
                                        widget.topic.pro,
                                        style: const TextStyle(fontSize: 14),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(top: 40),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 10),
                            width: MediaQuery.of(context).size.width * 0.9,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.grey.shade100),
                            child: Form(
                              key: formKey,
                              child: TextFormField(
                                validator: (value) {
                                  return value!.isEmpty
                                      ? "Message cannot be blank."
                                      : null;
                                },
                                controller: messageController,
                                maxLines: 5,
                                minLines: 1,
                                decoration: const InputDecoration.collapsed(
                                  hintText: "Write message here...",
                                  hintStyle: TextStyle(color: Colors.grey),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(
                              top: 30,
                            ),
                            width: MediaQuery.of(context).size.width * 0.9,
                            child: GestureDetector(
                              onTap: () => sendMessageRequest(),
                              child: const PurpleButton("Send Message"),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
      ),
    );
  }
}
