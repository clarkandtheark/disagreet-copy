import 'package:flutter/material.dart';
import 'package:disagreet_flutter/views/onboarding/widgets/widgets.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';

class Demo extends StatelessWidget {
  final TabController tabController;

  const Demo({
    Key? key,
    required this.tabController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final controller = TextEditingController();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 50),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomTextHeader(text: 'What\'s Your Gender?'),
                SizedBox(height: 10),
                CustomCheckbox(text: 'MALE'),
                CustomCheckbox(text: 'FEMALE'),
                SizedBox(height: 50),
                CustomTextHeader(text: 'What\'s Your Age?'),
                CustomTextField(
                  hint: 'ENTER YOUR AGE',
                  // controller: controller,
                ),
              ],
            ),
          ),
          Expanded(child: Container()),
          SingleChildScrollView(
            child: Column(
              children: [
                StepProgressIndicator(
                  totalSteps: 4,
                  currentStep: 2,
                  selectedColor: Theme.of(context).primaryColor,
                  unselectedColor: Theme.of(context).backgroundColor,
                ),
                SizedBox(height: 10),
                CustomButton(tabController: tabController, text: 'NEXT STEP'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
