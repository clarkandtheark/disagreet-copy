import 'package:flutter/material.dart';
import 'package:disagreet_flutter/views/onboarding/widgets/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

class Start extends StatelessWidget {
  final TabController tabController;

  const Start({
    Key? key,
    required this.tabController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 50),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              // Container(
              //   height: 200,
              //   width: 200,
              //   child: SvgPicture.asset(
              //     'assets/disagreet.svg',
              //   ),
              // ),
              // SizedBox(height: 50),
              Text(
                'Welcome to Disagreet',
                style: Theme.of(context).textTheme.headline3,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              Text(
                'Disagreet is a place where all ideologies are welcome and coming to understanding is the main goal. You will have the opportunity to speak with those who have a differing opinion from you and engage in meaningful dialogue',
                style: Theme.of(context)
                    .textTheme
                    .headline6!
                    .copyWith(height: 1.8),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          CustomButton(tabController: tabController, text: 'START')
        ],
      ),
    );
  }
}
