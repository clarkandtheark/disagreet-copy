import 'package:disagreet_flutter/services/auth.dart';
import 'package:disagreet_flutter/widget/buttons.dart';
import 'package:disagreet_flutter/widget/emailConfirmation.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key? key}) : super(key: key);

  @override
  _ForgotPasswordState createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  final formKey = GlobalKey<FormState>();
  bool isLoading = false;
  bool messageSent = false;
  TextEditingController emailTextEditingController = TextEditingController();
  AuthMethods authMethods = AuthMethods();

  sendPasswordReset() {
    if (formKey.currentState!.validate()) {
      setState(() {
        isLoading = true;
      });
      authMethods.resetPassword(emailTextEditingController.text)!.then((val) {
        setState(() {
          messageSent = true;
          isLoading = false;
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
          appBar: appBarMain(context, "Reset Password") as PreferredSizeWidget,
          body: isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                  strokeWidth: 6,
                ))
              : messageSent
                  ? const EmailConfirmation()
                  : SingleChildScrollView(
                      child: Container(
                          height: MediaQuery.of(context).size.height - 50,
                          alignment: Alignment.topCenter,
                          child: Container(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 24),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const SizedBox(height: 50),
                                    Text(
                                        'Please enter your email below and hit submit. A link to reset your password will be sent to your email.',
                                        style: simpleTextStyle()),
                                    const SizedBox(height: 32),
                                    Form(
                                      key: formKey,
                                      child: TextFormField(
                                          controller:
                                              emailTextEditingController,
                                          validator: (value) {
                                            return RegExp(
                                                        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                                    .hasMatch(value!)
                                                ? null
                                                : "Please enter a valid email";
                                          },
                                          style: simpleTextStyle(),
                                          decoration: textFieldInputDecoration(
                                              "Email")),
                                    ),
                                    const SizedBox(
                                      height: 32,
                                    ),
                                    GestureDetector(
                                      onTap: () => sendPasswordReset(),
                                      child: const PurpleButton("Send Email"),
                                    ),
                                    const SizedBox(height: 100),
                                  ]))))),
    );
  }
}
