import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/views/chatView.dart';
import 'package:disagreet_flutter/widget/ConversationTile.dart';
import 'package:disagreet_flutter/widget/searchList.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  DatabaseMethods databaseMethods = DatabaseMethods();
  TextEditingController? searchController = TextEditingController();
  String dropDownValue = "topic";

  List<QueryDocumentSnapshot>? searchResults;

  initiateSearch() async {
    QuerySnapshot? searchSnapshot;

    if (dropDownValue == "topic") {
      searchSnapshot =
          await databaseMethods.getConversationsByTopic(searchController!.text);
      setState(() {
        searchResults = searchSnapshot!.docs.where((value) {
          return value['status'] == 'inProgress';
        }).toList();
      });
    } else {
      searchSnapshot =
          await databaseMethods.getConversationsByName(searchController!.text);
      setState(() {
        searchResults = searchSnapshot!.docs
            .where((value) => value['status'] == 'inProgress')
            .toList();
      });
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: appBarMain(context, "Search") as PreferredSizeWidget,
        body: Column(
          children: [
            Container(
              color: const Color(0x54FFFFFF),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.deepPurple.shade100,
                    ),
                    margin: const EdgeInsets.only(right: 10),
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: DropdownButton(
                      value: dropDownValue,
                      icon: const Icon(Icons.arrow_drop_down_circle,
                          color: Colors.deepPurple),
                      dropdownColor: Colors.deepPurple.shade100,
                      elevation: 5,
                      onChanged: (String? newValue) {
                        setState(() {
                          dropDownValue = newValue!;
                        });
                      },
                      items: const [
                        DropdownMenuItem(
                          value: "topic",
                          child: Text("Topic"),
                        ),
                        DropdownMenuItem(value: "name", child: Text("Name"))
                      ],
                    ),
                  ),
                  Expanded(
                      child: TextField(
                          controller: searchController,
                          style: const TextStyle(color: Colors.black),
                          decoration: const InputDecoration(
                              hintText: "Search value...",
                              hintStyle: TextStyle(color: Colors.black38)))),
                  GestureDetector(
                    onTap: () {
                      initiateSearch();
                    },
                    child: Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                            gradient: const LinearGradient(
                                colors: [Color(0x36FFFFFF), Color(0x0FFFFFFF)]),
                            borderRadius: BorderRadius.circular(40)),
                        padding: const EdgeInsets.all(12),
                        child: const Icon(Icons.search)),
                  ),
                ],
              ),
            ),
            SearchList(searchResults: searchResults)
          ],
        ),
      ),
    );
  }
}
