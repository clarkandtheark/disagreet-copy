class UserClass {
  String? userId;
  UserClass({this.userId});
}
