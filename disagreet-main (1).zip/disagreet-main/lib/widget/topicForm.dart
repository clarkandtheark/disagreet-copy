import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/models/topic_model.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/views/matchPage.dart';
import 'package:disagreet_flutter/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TopicForm extends StatefulWidget {
  final Topic topic;
  final double stanceNum;
  final String stanceEntry;

  const TopicForm(
      {required this.topic,
      required this.stanceNum,
      required this.stanceEntry});

  @override
  _TopicFormState createState() {
    return _TopicFormState();
  }
}

class _TopicFormState extends State<TopicForm> {
  final DatabaseMethods databaseMethods = DatabaseMethods();
  final _formKey = GlobalKey<FormState>();
  double _stanceSlider = 0;
  String _enteredText = '';
  String _topicName = '';

  @override
  void initState() {
    _stanceSlider = widget.stanceNum;
    _enteredText = widget.stanceEntry;
    _topicName = widget.topic.topicName.toLowerCase();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          TextFormField(
            initialValue: _enteredText,
            // The validator receives the text that the user has entered.
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter some text';
              }
              return null;
            },
            style: simpleTextStyle(),
            keyboardType: TextInputType.multiline,
            maxLines: null,
            decoration: InputDecoration(
                labelText: 'Enter stance here',
                counterText: '${_enteredText.length.toString()} / 250'),
            // textFieldInputDecoration(labelText: "Edit your stance"),
            inputFormatters: [LengthLimitingTextInputFormatter(250)],
            onChanged: (value) {
              setState(() {
                _enteredText = value;
              });
            },
          ),
          Flexible(
            flex: 1,
            child: Slider(
              activeColor: Colors.deepPurpleAccent,
              min: -10.0,
              max: 10.0,
              onChanged: (newPosition) {
                setState(() => _stanceSlider = newPosition);
              },
              value: _stanceSlider,
            ),
          ),
          Row(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text(widget.topic.con),
              ),
              const Spacer(),
              Align(
                alignment: Alignment.centerRight,
                child: Text(widget.topic.pro),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () async {
              // Validate returns true if the form is valid, or false otherwise.
              if (_formKey.currentState!.validate()) {
                // If the form is valid, display a snackbar. In the real world,
                // you'd often call a server or save the information in a database.
                await databaseMethods.addUserToTopic(
                    _topicName,
                    Constants.myUid,
                    '${Constants.myFirstName} ${Constants.myLastName}',
                    _stanceSlider,
                    _enteredText,
                    Constants.myImageUrl);
                databaseMethods.calculatePeopleTalking(widget.topic.id);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Processing Data')),
                );
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MatchPage(
                      stanceNum: _stanceSlider,
                      topicInfo: widget.topic,
                      userInfoId: "${widget.topic.id}}-${Constants.myUid}",
                    ),
                  ),
                );
              }
              // redirect upon submission to swipePage
              // with params -> userInfoId (abortion-UID) (to get all other users in that collection except curr User"
              // -> collectionName (topic-users)
            },
            child: const Text('Submit'),
          ),
        ],
      ),
    );
  }
}
