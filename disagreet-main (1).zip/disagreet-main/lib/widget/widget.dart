import 'package:disagreet_flutter/helper/authenticate.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

Widget appBarMain(BuildContext context, String title) {
  return AppBar(
      title: Text(title,
          style:
              GoogleFonts.righteous(textStyle: const TextStyle(fontSize: 35))));
}

Widget appBarWithButton(BuildContext context, String title, Widget button) {
  return AppBar(
      title: Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(title,
          style:
              GoogleFonts.righteous(textStyle: const TextStyle(fontSize: 16))),
      button
    ],
  ));
}

Widget displayStarRating(double _rating) {
  return RatingBarIndicator(
    rating: _rating,
    itemBuilder: (context, index) => Icon(
      Icons.star,
      color: Colors.amber,
    ),
    itemCount: 5,
    itemSize: 25.0,
  );
}

Widget appBarLogout(
    BuildContext context, Function signOut, String title, bool tabs) {
  return AppBar(
      title: Text(title,
          style:
              GoogleFonts.righteous(textStyle: const TextStyle(fontSize: 35))),
      actions: [
        logoutButton(context, signOut),
      ],
      bottom: tabs
          ? const TabBar(
              tabs: [
                Tab(
                  icon: Icon(Icons.message),
                  text: "Messages",
                ),
                Tab(
                  icon: Icon(Icons.people),
                  text: "Requests",
                ),
                Tab(
                  icon: Icon(Icons.done),
                  text: "Finished",
                )
              ],
            )
          : null);
}

Widget logoutButton(BuildContext context, Function signOut) {
  return GestureDetector(
    onTap: () {
      signOut();
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => const Authenticate()));
    },
    child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: const Icon(Icons.logout)),
  );
}

InputDecoration textFieldInputDecoration(String hintText) {
  return InputDecoration(
      hintText: hintText,
      hintStyle: const TextStyle(color: Colors.grey),
      focusedBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.purple)),
      enabledBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.purple)));
}

TextStyle simpleTextStyle() {
  return const TextStyle(color: Colors.black, fontSize: 16);
}

TextStyle mediumTextStyle() {
  return const TextStyle(color: Colors.white, fontSize: 17);
}

TextStyle headline1() {
  return const TextStyle(
      color: Color(0xFF2B2E4A), fontWeight: FontWeight.bold, fontSize: 36);
}

TextStyle headline2() {
  return const TextStyle(
      color: Color(0xFF2B2E4A), fontWeight: FontWeight.bold, fontSize: 24);
}

TextStyle headline3() {
  return const TextStyle(
      color: Color(0xFF2B2E4A), fontWeight: FontWeight.bold, fontSize: 18);
}

TextStyle headline4() {
  return const TextStyle(
      color: Color(0xFF2B2E4A), fontWeight: FontWeight.bold, fontSize: 16);
}

TextStyle headline5() {
  return const TextStyle(
      color: Color(0xFF2B2E4A), fontWeight: FontWeight.bold, fontSize: 14);
}

TextStyle headline6() {
  return const TextStyle(
      color: Color(0xFF2B2E4A), fontWeight: FontWeight.bold, fontSize: 14);
}

TextStyle bodyText1() {
  return const TextStyle(
      color: Color(0xFF2B2E4A), fontWeight: FontWeight.normal, fontSize: 12);
}

TextStyle bodyText2() {
  return const TextStyle(
      color: Color(0xFF2B2E4A), fontWeight: FontWeight.normal, fontSize: 10);
}
