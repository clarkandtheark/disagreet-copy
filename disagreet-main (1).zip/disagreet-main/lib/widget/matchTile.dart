import 'dart:math';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/helper/helperfunctions.dart';
import 'package:disagreet_flutter/models/stance_model.dart';
import 'package:disagreet_flutter/models/topic_model.dart';
import 'package:disagreet_flutter/services/database.dart';
import 'package:disagreet_flutter/views/chatView.dart';
import 'package:disagreet_flutter/views/startConversation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swipable/flutter_swipable.dart';

class MatchTile extends StatelessWidget {
  final Topic topic;
  final Stance stance;

  const MatchTile({required this.topic, required this.stance});

  swipeRight(BuildContext context) async {
    DatabaseMethods databaseMethods = DatabaseMethods();
    var messageId = HelperFunctions.getConversationId(
        Constants.myUid, stance.id.split("-")[1], topic.id);

    DocumentSnapshot documentSnapshot =
        await databaseMethods.getConversationById(messageId);

    if (documentSnapshot.exists) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChatView(
              documentSnapshot.id,
              documentSnapshot['topic'],
              stance.fullName,
              documentSnapshot['status'] == 'finished' ? false : true),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => StartConversation(
            conversationId: messageId,
            stance: stance,
            topic: topic,
          ),
        ),
      );
    }
  }

  swipeLeft() {}

  @override
  Widget build(BuildContext context) {
    return Swipable(
        child: Stack(
          children: [
            Container(
                decoration: stance.profileImage == ""
                    ? BoxDecoration(
                        color: Colors.grey.shade400,
                        borderRadius: BorderRadius.circular(16),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        image: DecorationImage(
                            image: NetworkImage(
                              stance.profileImage,
                            ),
                            fit: BoxFit.cover),
                      ),
                child: stance.profileImage == ""
                    ? Center(
                        child: Text(
                          stance.fullName.split(" ")[0].substring(0, 1) +
                              stance.fullName.split(" ")[1].substring(0, 1),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 100,
                          ),
                        ),
                      )
                    : null),
            Align(
              alignment: Alignment.bottomCenter,
              child: FractionallySizedBox(
                alignment: Alignment.bottomCenter,
                heightFactor: 0.5,
                widthFactor: 1,
                child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) =>
                      Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: LinearGradient(
                        colors: [
                          Colors.black,
                          Colors.black.withOpacity(0.7),
                          Colors.black.withOpacity(0)
                        ],
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                      ),
                    ),
                    child: Column(
                      verticalDirection: VerticalDirection.up,
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: constraints.maxHeight * 0.3,
                          alignment: Alignment.bottomCenter,
                          child: Column(
                            children: [
                              SliderTheme(
                                data: const SliderThemeData(
                                  activeTrackColor: Colors.deepPurple,
                                  inactiveTrackColor: Colors.deepPurple,
                                  thumbColor: Colors.white,
                                  trackShape: RectangularSliderTrackShape(),
                                ),
                                child: Slider(
                                  value: stance.stanceNum,
                                  min: -10,
                                  max: 10,
                                  onChanged: (value) {},
                                ),
                              ),
                              Row(
                                children: [
                                  Text(topic.con,
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 14)),
                                  const Spacer(),
                                  Text(topic.pro,
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 14)),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Container(
                          alignment: Alignment.bottomLeft,
                          child: ConstrainedBox(
                            constraints: BoxConstraints(
                                maxHeight: constraints.maxHeight * 0.40,
                                minHeight: 0),
                            child: AutoSizeText(
                              stance.stanceEntry,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 16),
                            ),
                          ),
                        ),
                        Container(
                          height: constraints.maxHeight * 0.2,
                          alignment: Alignment.bottomLeft,
                          child: AutoSizeText(
                            stance.fullName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 40,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        onSwipeRight: (details) {
          swipeRight(context);
        },
        onSwipeLeft: (details) {
          swipeLeft();
        });
  }
}
