import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:flutter/material.dart';

import 'ConversationTile.dart';

class SearchList extends StatelessWidget {
  final List<QueryDocumentSnapshot>? searchResults;

  const SearchList({this.searchResults});

  @override
  Widget build(BuildContext context) {
    return searchResults != null
        ? ListView.builder(
            itemCount: searchResults!.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return ConversationTile(
                topic: searchResults![index]["topic"],
                fullName: searchResults![index]["names"][0] ==
                        "${Constants.myFirstName} ${Constants.myLastName}"
                    ? searchResults![index]["names"][1]
                    : searchResults![index]["names"][0],
                id: searchResults![index].id,
                latestMessageMap: searchResults![index]["latestMessage"],
                inProgress: true,
                imageUrl: searchResults![index]["imageUrls"][0] ==
                        Constants.myImageUrl
                    ? searchResults![index]["imageUrls"][1]
                    : searchResults![index]["imageUrls"][0],
              );
            })
        : Container();
    ;
  }
}
