import 'package:auto_size_text/auto_size_text.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/helper/helperfunctions.dart';
import 'package:disagreet_flutter/views/requestPage.dart';
import 'package:flutter/material.dart';

class RequestTile extends StatelessWidget {
  final String messageId;
  final String fullName;
  final String topic;
  final Map<String, dynamic> latestMessageMap;
  final String imageUrl;
  const RequestTile(
      {required this.messageId,
      required this.fullName,
      required this.topic,
      required this.latestMessageMap,
      required this.imageUrl});

  String convertDateTime(time) {
    var today = DateTime.now();
    var dateDif = today.difference(time);
    if (dateDif.inHours.abs() < 24) {
      return "${time.hour % 12}:${time.minute < 10 ? "0${time.minute}" : time.minute} ${time.hour > 12 ? "PM" : "AM"}";
    }
    return "${time.month}/${time.day}/${time.year.toString().substring(2, 4)}";
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      height: MediaQuery.of(context).size.height * .105,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Colors.grey.shade600, width: 1),
        ),
      ),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).size.height * 0.01,
        bottom: MediaQuery.of(context).size.height * 0.01,
        right: MediaQuery.of(context).size.width * .015,
        left: MediaQuery.of(context).size.width * .03,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * .08,
            width: MediaQuery.of(context).size.height * .08,
            alignment: Alignment.center,
            decoration: imageUrl == ""
                ? BoxDecoration(
                    borderRadius: BorderRadius.circular(
                        MediaQuery.of(context).size.height * .08),
                    color: HelperFunctions.getRandomColor(fullName.hashCode),
                  )
                : BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage(imageUrl),
                      fit: BoxFit.cover,
                    ),
                    borderRadius: BorderRadius.circular(
                        MediaQuery.of(context).size.height * .08),
                  ),
            child: imageUrl == ""
                ? Center(
                    child: Text(
                      fullName.split(" ")[0].substring(0, 1) +
                          fullName.split(" ")[1].substring(0, 1),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      ),
                    ),
                  )
                : null,
          ),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.03,
          ),
          SizedBox(
            width: (MediaQuery.of(context).size.width * 0.7 -
                MediaQuery.of(context).size.height * 0.08),
            child: Column(
              children: [
                Align(
                  alignment: Alignment.topLeft,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(vertical: 2, horizontal: 5),
                    decoration: BoxDecoration(
                        color: Colors.deepPurple.shade100,
                        borderRadius: BorderRadius.circular(10)),
                    child: AutoSizeText(
                      topic,
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Expanded(
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: latestMessageMap['sendBy'] == Constants.myFirstName
                        ? AutoSizeText.rich(
                            TextSpan(
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                              ),
                              children: [
                                const TextSpan(text: "Waiting for "),
                                TextSpan(
                                  text: fullName.split(" ")[0],
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                                const TextSpan(text: " to respond.")
                              ],
                            ),
                            maxLines: 2,
                          )
                        : AutoSizeText.rich(
                            TextSpan(
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                              ),
                              children: [
                                TextSpan(
                                    text: fullName.split(" ")[0],
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold)),
                                const TextSpan(text: " would like to connect.")
                              ],
                            ),
                            maxLines: 2,
                          ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.225,
            child: latestMessageMap["sendBy"] == Constants.myFirstName
                ? Row(
                    children: [
                      AutoSizeText(
                        "${convertDateTime(latestMessageMap["time"].toDate())} ",
                      ),
                      const Icon(Icons.access_time),
                    ],
                  )
                : GestureDetector(
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => RequestPage(
                                  fullName: fullName,
                                  messageId: messageId,
                                  topic: topic,
                                  latestMessageMap: latestMessageMap,
                                ))),
                    child: Container(
                      height: 30,
                      width: 90,
                      decoration: BoxDecoration(
                          color: Colors.deepPurple,
                          borderRadius: BorderRadius.circular(10)),
                      child: Center(
                        child: AutoSizeText(
                          "See Details",
                          style: TextStyle(color: Colors.grey.shade200),
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
