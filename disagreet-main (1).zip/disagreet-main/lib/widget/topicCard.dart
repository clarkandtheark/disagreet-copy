import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:disagreet_flutter/views/topicDefine.dart';
import 'package:flutter/material.dart';

class TopicCard extends StatelessWidget {
  final QueryDocumentSnapshot<Object?> topicInfo;

  const TopicCard(this.topicInfo);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (context) => TopicDefine(topicInfo))),
      child: Container(
          width: MediaQuery.of(context).size.width / 2.4,
          height: MediaQuery.of(context).size.width / 2.4,
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.bottomLeft,
                end: Alignment.topRight,
                colors: [Colors.deepPurple.shade200, Colors.deepPurpleAccent]),
            borderRadius: BorderRadius.circular(20),
          ),
          padding: const EdgeInsets.all(20),
          margin: const EdgeInsets.all(10),
          child: Align(
            alignment: Alignment.topLeft,
            child: Column(
              children: [
                Container(
                  alignment: Alignment.topLeft,
                  child: AutoSizeText(
                    topicInfo["name"] as String,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey.shade100,
                    ),
                  ),
                ),
                Container(
                  alignment: Alignment.topLeft,
                  child: AutoSizeText(
                    "${topicInfo["pro"]} & ${topicInfo["con"]}",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey.shade100,
                    ),
                    maxLines: 2,
                  ),
                ),
                //     ],
                //   ),
                // ),
                const Spacer(),
                Container(
                  alignment: Alignment.topLeft,
                  child: AutoSizeText(
                    topicInfo["peopleTalking"] == 1
                        ? "${topicInfo["peopleTalking"]} Person Talking"
                        : "${topicInfo["peopleTalking"]} People Talking",
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade100),
                    maxLines: 1,
                  ),
                ),
              ],
            ),
          )),
    );
  }
}
