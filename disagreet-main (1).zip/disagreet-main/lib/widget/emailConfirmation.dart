import 'package:flutter/material.dart';

class EmailConfirmation extends StatelessWidget {
  const EmailConfirmation({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.topCenter,
      child: Column(
        children: [
          const SizedBox(height: 40),
          Icon(
            Icons.check_circle,
            size: 100,
            color: Colors.green[800],
          ),
          const SizedBox(height: 16),
          const Text(
            "The message has been sent!",
            style: TextStyle(
              fontSize: 25,
            ),
          ),
        ],
      ),
    );
  }
}
