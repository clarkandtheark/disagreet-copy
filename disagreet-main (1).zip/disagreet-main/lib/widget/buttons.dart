import 'package:flutter/material.dart';

class PurpleButton extends StatelessWidget {
  final String buttonText;
  const PurpleButton(this.buttonText);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [Colors.deepPurple, Colors.deepPurpleAccent]),
          borderRadius: BorderRadius.circular(30)),
      child: Text(
        buttonText,
        style: const TextStyle(color: Colors.white, fontSize: 17),
      ),
    );
  }
}

class GoogleButton extends StatelessWidget {
  final String buttonText;

  const GoogleButton(this.buttonText);

  @override
  Widget build(BuildContext context) {
    return Container(
        alignment: Alignment.center,
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.symmetric(vertical: 11),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: Colors.deepPurple, width: 1)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
                padding: const EdgeInsets.only(right: 30),
                child: Image.asset("assets/images/google.png", height: 35)),
            Text(
              buttonText,
              style: const TextStyle(color: Colors.black, fontSize: 17),
            ),
          ],
        ));
  }
}
