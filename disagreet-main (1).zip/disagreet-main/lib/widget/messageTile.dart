import 'package:flutter/material.dart';
import 'package:flutter_chat_bubble/bubble_type.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:flutter_chat_bubble/clippers/chat_bubble_clipper_2.dart';

class MessageTile extends StatelessWidget {
  final String message;
  final bool isSendByMe;
  const MessageTile(this.message, this.isSendByMe);

  @override
  Widget build(BuildContext context) {
    return isSendByMe
        ? getSenderView(
            ChatBubbleClipper2(type: BubbleType.sendBubble), context)
        : getReceiverView(
            ChatBubbleClipper2(type: BubbleType.receiverBubble), context);
  }

  getSenderView(CustomClipper clipper, BuildContext context) => ChatBubble(
        clipper: clipper,
        alignment: Alignment.topRight,
        margin: const EdgeInsets.only(top: 20),
        backGroundColor: Colors.deepPurpleAccent,
        child: Container(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.7,
          ),
          child: Text(
            message,
            style: const TextStyle(color: Colors.white),
          ),
        ),
      );

  getReceiverView(CustomClipper clipper, BuildContext context) => ChatBubble(
        clipper: clipper,
        backGroundColor: const Color(0xffE7E7ED),
        margin: const EdgeInsets.only(top: 20),
        child: Container(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.7,
          ),
          child: Text(
            message,
            style: const TextStyle(color: Colors.black),
          ),
        ),
      );
}
