import 'package:auto_size_text/auto_size_text.dart';
import 'package:disagreet_flutter/helper/constants.dart';
import 'package:disagreet_flutter/helper/helperfunctions.dart';
import 'package:flutter/material.dart';
import 'package:disagreet_flutter/views/chatView.dart';

class ConversationTile extends StatelessWidget {
  final bool inProgress;
  final String fullName;
  final String topic;
  final Map<String, dynamic> latestMessageMap;
  final String id;
  final String imageUrl;

  const ConversationTile(
      {required this.fullName,
      required this.topic,
      required this.latestMessageMap,
      required this.id,
      required this.inProgress,
      required this.imageUrl});

  String convertDateTime(time) {
    var today = DateTime.now();
    var dateDif = today.difference(time);
    if (dateDif.inHours.abs() < 24) {
      return "${time.hour % 12}:${time.minute < 10 ? "0${time.minute}" : time.minute} ${time.hour > 12 ? "PM" : "AM"}";
    }
    return "${time.month}/${time.day}/${time.year.toString().substring(2, 4)}";
  }

  @override
  Widget build(BuildContext context) {
    var messageHeadGroup = AutoSizeGroup();
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ChatView(
                      id,
                      topic,
                      fullName,
                      inProgress,
                    )));
      }, //71.68
      child: Container(
        alignment: Alignment.center,
        height: MediaQuery.of(context).size.height * .105,
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: Colors.grey.shade600, width: 1),
          ),
        ),
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).size.height * 0.01,
          bottom: MediaQuery.of(context).size.height * 0.01,
          right: MediaQuery.of(context).size.width * .015,
          left: MediaQuery.of(context).size.width * .03,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: MediaQuery.of(context).size.height * .08,
              width: MediaQuery.of(context).size.height * .08,
              alignment: Alignment.center,
              decoration: imageUrl == ""
                  ? BoxDecoration(
                      borderRadius: BorderRadius.circular(
                          MediaQuery.of(context).size.height * .08),
                      color: HelperFunctions.getRandomColor(fullName.hashCode),
                    )
                  : BoxDecoration(
                      image: DecorationImage(
                        image: NetworkImage(imageUrl),
                        fit: BoxFit.cover,
                      ),
                      borderRadius: BorderRadius.circular(
                          MediaQuery.of(context).size.height * .08),
                    ),
              child: imageUrl == ""
                  ? Center(
                      child: AutoSizeText(
                        fullName.split(" ")[0].substring(0, 1) +
                            fullName.split(" ")[1].substring(0, 1),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                        ),
                      ),
                    )
                  : null,
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.03,
            ),
            SizedBox(
              width: (MediaQuery.of(context).size.width * 0.925 -
                  MediaQuery.of(context).size.height * 0.08),
              child: Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.035,
                    child: Row(
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.62,
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 2, horizontal: 5),
                                decoration: BoxDecoration(
                                    color: Colors.deepPurple.shade100,
                                    borderRadius: BorderRadius.circular(
                                        MediaQuery.of(context).size.height *
                                            0.0125)),
                                child: AutoSizeText(
                                  topic,
                                  style: const TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold),
                                  group: messageHeadGroup,
                                ),
                              ),
                              Expanded(
                                child: AutoSizeText(
                                  " - $fullName",
                                  style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                  group: messageHeadGroup,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Align(
                            alignment: Alignment.topRight,
                            child: AutoSizeText(
                              convertDateTime(
                                  latestMessageMap['time'].toDate()),
                              style: const TextStyle(fontSize: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      alignment: Alignment.topLeft,
                      child: AutoSizeText(
                        "${latestMessageMap["sendBy"] == Constants.myFirstName ? "Me" : latestMessageMap["sendBy"]}: ${latestMessageMap["message"]}",
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 16,
                        ),
                        maxLines: 2,
                        minFontSize: 14,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
