import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:disagreet_flutter/database/database_repository.dart';
import 'package:equatable/equatable.dart';

part 'image_event.dart';
part 'image_state.dart';

class ImageBloc extends Bloc<ImageEvent, ImageState> {
  final DatabaseRepository _databaseRepository;
  StreamSubscription? _databaseSubscription;

  ImageBloc({required DatabaseRepository databaseRepository})
      : _databaseRepository = databaseRepository,
        super(ImageLoading());

  @override
  Stream<ImageState> mapEventToState(ImageEvent event) async* {
    if (event is LoadImage) {
      yield* _mapLoadImageToState();
    }
    if (event is UpdateImage) {
      yield* _mapUpdateImageToState(event);
    }
  }

  Stream<ImageState> _mapLoadImageToState() async* {
    _databaseSubscription?.cancel();

    _databaseRepository.getUser().listen(
          (user) => add(
            UpdateImage(user.imageUrl),
          ),
        );
  }

  Stream<ImageState> _mapUpdateImageToState(UpdateImage event) async* {
    yield ImageLoaded(event.imageUrl);
  }
}
