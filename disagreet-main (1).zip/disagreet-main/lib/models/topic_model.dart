class Topic {
  final String id;
  final String topicName;
  final String pro;
  final String con;
  final String description;
  final int? peopleTalking;

  Topic(
      {required this.id,
      required this.topicName,
      required this.pro,
      required this.con,
      required this.description,
      this.peopleTalking});
}
