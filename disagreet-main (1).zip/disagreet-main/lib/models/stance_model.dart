class Stance {
  final String id;
  final String stanceEntry;
  final double stanceNum;
  final String fullName;
  final String profileImage;

  Stance(
      {required this.id,
      required this.stanceEntry,
      required this.stanceNum,
      required this.fullName,
      required this.profileImage});
}
